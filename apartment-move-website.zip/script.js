// App State
let currentArea = 'kitchen';
let items = {
    kitchen: [],
    bedroom: [],
    living: [],
    bathroom: [],
    garden: [],
    office: []
};

// DOM Elements
const areaTitle = document.getElementById('area-title');
const itemsContainer = document.getElementById('items-container');
const addItemBtn = document.getElementById('add-item-btn');
const addItemModal = document.getElementById('add-item-modal');
const closeModalBtn = document.getElementById('close-modal');
const cancelAddBtn = document.getElementById('cancel-add');
const addItemForm = document.getElementById('add-item-form');
const navBtns = document.querySelectorAll('.nav-btn');

// Stats elements
const totalItemsEl = document.getElementById('total-items');
const totalBudgetEl = document.getElementById('total-budget');
const completedItemsEl = document.getElementById('completed-items');

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    loadData();
    setupEventListeners();
    renderItems();
    updateStats();
});

// Event Listeners
function setupEventListeners() {
    // Navigation
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const area = btn.dataset.area;
            switchArea(area);
        });
    });

    // Modal
    addItemBtn.addEventListener('click', openModal);
    closeModalBtn.addEventListener('click', closeModal);
    cancelAddBtn.addEventListener('click', closeModal);
    addItemModal.addEventListener('click', (e) => {
        if (e.target === addItemModal) closeModal();
    });

    // Form
    addItemForm.addEventListener('submit', handleAddItem);
}

// Area Navigation
function switchArea(area) {
    currentArea = area;
    
    // Update navigation
    navBtns.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.area === area) {
            btn.classList.add('active');
        }
    });

    // Update area title
    const areaNames = {
        kitchen: 'Kitchen',
        bedroom: 'Bedroom',
        living: 'Living Room',
        bathroom: 'Bathroom',
        garden: 'Garden',
        office: 'Office'
    };
    areaTitle.textContent = areaNames[area];

    // Render items for this area
    renderItems();
    updateStats();
}

// Modal Functions
function openModal() {
    addItemModal.classList.add('show');
    document.getElementById('item-name').focus();
}

function closeModal() {
    addItemModal.classList.remove('show');
    addItemForm.reset();
}

// Add Item
function handleAddItem(e) {
    e.preventDefault();
    
    const formData = new FormData(addItemForm);
    const item = {
        id: Date.now().toString(),
        name: formData.get('item-name') || document.getElementById('item-name').value,
        size: formData.get('item-size') || document.getElementById('item-size').value,
        price: parseFloat(formData.get('item-price') || document.getElementById('item-price').value),
        notes: formData.get('item-notes') || document.getElementById('item-notes').value,
        completed: false,
        createdAt: new Date().toISOString()
    };

    items[currentArea].push(item);
    saveData();
    renderItems();
    updateStats();
    closeModal();
}

// Render Items
function renderItems() {
    const areaItems = items[currentArea];
    
    if (areaItems.length === 0) {
        itemsContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-box-open"></i>
                <h3>No items yet</h3>
                <p>Start adding items to your ${currentArea} list by clicking the "Add Item" button above.</p>
            </div>
        `;
        return;
    }

    itemsContainer.innerHTML = areaItems.map(item => `
        <div class="item-card ${item.completed ? 'completed' : ''}" data-id="${item.id}">
            <div class="item-header">
                <div class="item-name">${item.name}</div>
                <div class="item-price">$${item.price.toFixed(2)}</div>
            </div>
            <div class="item-details">
                ${item.size ? `
                    <div class="item-detail">
                        <i class="fas fa-ruler-combined"></i>
                        <span>${item.size}</span>
                    </div>
                ` : ''}
                <div class="item-detail">
                    <i class="fas fa-calendar"></i>
                    <span>Added: ${new Date(item.createdAt).toLocaleDateString()}</span>
                </div>
            </div>
            ${item.notes ? `
                <div class="item-notes">
                    <i class="fas fa-sticky-note"></i>
                    ${item.notes}
                </div>
            ` : ''}
            <div class="item-actions">
                <button class="action-btn complete-btn" onclick="toggleComplete('${item.id}')">
                    <i class="fas ${item.completed ? 'fa-undo' : 'fa-check'}"></i>
                    ${item.completed ? 'Undo' : 'Complete'}
                </button>
                <button class="action-btn delete-btn" onclick="deleteItem('${item.id}')">
                    <i class="fas fa-trash"></i>
                    Delete
                </button>
            </div>
        </div>
    `).join('');
}

// Toggle Item Completion
function toggleComplete(itemId) {
    const item = items[currentArea].find(item => item.id === itemId);
    if (item) {
        item.completed = !item.completed;
        saveData();
        renderItems();
        updateStats();
    }
}

// Delete Item
function deleteItem(itemId) {
    if (confirm('Are you sure you want to delete this item?')) {
        items[currentArea] = items[currentArea].filter(item => item.id !== itemId);
        saveData();
        renderItems();
        updateStats();
    }
}

// Update Statistics
function updateStats() {
    const areaItems = items[currentArea];
    const totalItems = areaItems.length;
    const totalBudget = areaItems.reduce((sum, item) => sum + item.price, 0);
    const completedItems = areaItems.filter(item => item.completed).length;

    totalItemsEl.textContent = totalItems;
    totalBudgetEl.textContent = `$${totalBudget.toFixed(2)}`;
    completedItemsEl.textContent = completedItems;
}

// Data Persistence
function saveData() {
    localStorage.setItem('apartmentMoveData', JSON.stringify(items));
}

function loadData() {
    const savedData = localStorage.getItem('apartmentMoveData');
    if (savedData) {
        items = JSON.parse(savedData);
    }
}

// Add some sample data for demonstration
function addSampleData() {
    if (Object.values(items).every(area => area.length === 0)) {
        items.kitchen = [
            {
                id: '1',
                name: 'Kitchen Table',
                size: '120cm x 80cm',
                price: 299.99,
                notes: 'Looking for a modern wooden table with 4 chairs',
                completed: false,
                createdAt: new Date().toISOString()
            },
            {
                id: '2',
                name: 'Refrigerator',
                size: '70cm x 60cm x 180cm',
                price: 899.99,
                notes: 'Stainless steel, French door style',
                completed: true,
                createdAt: new Date().toISOString()
            }
        ];
        
        items.bedroom = [
            {
                id: '3',
                name: 'Queen Bed Frame',
                size: '160cm x 200cm',
                price: 450.00,
                notes: 'Upholstered headboard, dark gray',
                completed: false,
                createdAt: new Date().toISOString()
            }
        ];
        
        items.living = [
            {
                id: '4',
                name: 'Sofa',
                size: '220cm x 85cm',
                price: 1200.00,
                notes: '3-seater, fabric, neutral color',
                completed: false,
                createdAt: new Date().toISOString()
            }
        ];
        
        saveData();
    }
}

// Initialize with sample data
document.addEventListener('DOMContentLoaded', function() {
    loadData();
    addSampleData();
    setupEventListeners();
    renderItems();
    updateStats();
}); 