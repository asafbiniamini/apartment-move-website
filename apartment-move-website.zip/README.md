# Our Apartment Move Planner

A beautiful, interactive website to help you and your partner plan your apartment move. Organize items by room, track prices, sizes, and completion status.

## Features

- **Room-based Organization**: Navigate between different areas of your apartment (Kitchen, Bedroom, Living Room, Bathroom, Garden, Office)
- **Item Management**: Add items with names, sizes, prices, and notes
- **Progress Tracking**: Mark items as completed and track your progress
- **Budget Monitoring**: See total budget for each area
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **Data Persistence**: Your data is saved locally in your browser

## How to Use

1. **Open the Website**: Simply open `index.html` in your web browser
2. **Navigate Between Rooms**: Click on the room buttons at the top to switch between different areas
3. **Add Items**: Click the "Add Item" button to add new items to the current room
4. **Track Progress**: Use the "Complete" button to mark items as done
5. **Monitor Budget**: View the statistics bar to see total items, budget, and completed items

## Adding Items

When you add an item, you can specify:
- **Item Name**: What you need to buy
- **Size/Dimensions**: Measurements or specifications
- **Price**: Cost of the item
- **Notes**: Additional details, brand preferences, or special requirements

## Sample Data

The website comes with some sample data to demonstrate the features:
- **Kitchen**: Kitchen table and refrigerator
- **Bedroom**: Queen bed frame
- **Living Room**: Sofa

You can delete these items or modify them as needed.

## Technical Details

- **Pure HTML/CSS/JavaScript**: No external dependencies required
- **Local Storage**: Data is saved in your browser's local storage
- **Responsive Design**: Works on all screen sizes
- **Modern UI**: Beautiful gradient design with smooth animations

## File Structure

```
apartment-move-website/
├── index.html          # Main HTML file
├── styles.css          # CSS styling
├── script.js           # JavaScript functionality
└── README.md          # This file
```

## Getting Started

1. Download or clone the files to your computer
2. Open `index.html` in your web browser
3. Start adding your items!

## Tips for Moving Planning

- **Start Early**: Begin planning at least 2-3 months before your move
- **Measure Everything**: Note down room dimensions and furniture sizes
- **Set Budgets**: Use the price tracking to stay within budget
- **Prioritize**: Mark the most important items first
- **Research**: Use the notes section to track specific brands or models you want

Enjoy planning your new home together! 🏠 